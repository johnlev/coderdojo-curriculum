# We are going to be making a guessing game, where the user guesses your favorite number

# Here we define a variable guess which holds the user's response to the question
#   The input function asks the user the question and gives back the string the user types in.
#   The int(...) syntax converts the string into an integer if it can
guess = int(input("What is my favorite number? "))

# =======================
# You write the following

my_favorite_number =

# If the guess is less than your favorite number, tell the user


# If the guess is more than your favorite number, ...


# If the guess is your favorite number, ...