"""
Week 4 Activity: Green Eggs and Ham
-----------------------------------
Draw green eggs and ham on a plate
"""

from cs1lib import *

