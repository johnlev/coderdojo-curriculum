# This weeks activity will be a password checker

# Enter the password
PASSWORD = "password123"

# The guess
guess = input("Password: ")

# Write a loop that checks the password
# Whenever the guess is wrong, tell the user and ask again


# When right, tell the user
