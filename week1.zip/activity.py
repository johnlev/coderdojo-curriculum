from Week1.car_activity import start, move_forward, turn_left, turn_right, park, done

# ==================
# You code this part
# Use start() to start the robot so it can move
start()
# Use move_forward() to drive the robot forward
move_forward()
# Use turn_left(), turn_right(), and move_forward() to get to the blue dot
turn_left()
move_forward()
turn_right()
move_forward()
# Park the robot using park()
park()
# ==================

done()
